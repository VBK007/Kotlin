package nr.king.kotlinpracticse

import android.os.Bundle
import android.view.Gravity
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import com.google.android.material.bottomnavigation.BottomNavigationView
import kotlinx.android.synthetic.main.activity_menu_home.*
import nr.king.kotlinpracticse.Fragment.*

class menuHome : AppCompatActivity(){


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu_home)
        setSupportActionBar(findViewById(R.id.toolbar))

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val drawerToggle = ActionBarDrawerToggle(this, drawer,toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close)
        drawer.addDrawerListener(drawerToggle)
        drawerToggle.syncState()




       botview.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener)




if (savedInstanceState==null){

    val fragment=homelay()
    supportFragmentManager.beginTransaction().replace(R.id.frala,fragment,fragment.javaClass.simpleName).commit()



}


    }







    private val mOnNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { menuItem ->
        when(menuItem.itemId){
            R.id.home->
            {
                val fragment=homelay()

                supportFragmentManager.beginTransaction().replace(R.id.frala,fragment,fragment.javaClass.simpleName).commit()

                return@OnNavigationItemSelectedListener true


            }
            R.id.sea->
            {
                val fragment=picturelay()

                supportFragmentManager.beginTransaction().replace(R.id.frala,fragment,fragment.javaClass.simpleName).commit()
                return@OnNavigationItemSelectedListener true
                finish()

            }


            R.id.add->{

                val fragment=cameralay()


                supportFragmentManager.beginTransaction().replace(R.id.frala,fragment,fragment.javaClass.simpleName).commit()
                return@OnNavigationItemSelectedListener true


            }




            R.id.notifi->{

                val fragment=notifi()


                supportFragmentManager.beginTransaction().replace(R.id.frala,fragment,fragment.javaClass.simpleName).commit()
                return@OnNavigationItemSelectedListener true


            }


            R.id.acc->{

                val fragment=displaypro()


                supportFragmentManager.beginTransaction().replace(R.id.frala,fragment,fragment.javaClass.simpleName).commit()
                return@OnNavigationItemSelectedListener true


            }



















        }

        false
    }



    private val navclickfunction =BottomNavigationView.OnNavigationItemReselectedListener{menuitem->

        when(menuitem.itemId){
            R.id.home->
            {
val fragment=homelay()

                supportFragmentManager.beginTransaction().replace(R.id.frala,fragment,fragment.javaClass.simpleName)

                return@OnNavigationItemReselectedListener


            }
                R.id.sea->
                {
                    val fragment=picturelay()

supportFragmentManager.beginTransaction().replace(R.id.frala,fragment,fragment.javaClass.simpleName)
finish()

                }


            R.id.add->{

val fragment=cameralay()


                supportFragmentManager.beginTransaction().replace(R.id.frala,fragment,fragment.javaClass.simpleName)


            }




            R.id.notifi->{

                val fragment=notifi()


                supportFragmentManager.beginTransaction().replace(R.id.frala,fragment,fragment.javaClass.simpleName)


            }


            R.id.acc->{

                val fragment=displaypro()


                supportFragmentManager.beginTransaction().replace(R.id.frala,fragment,fragment.javaClass.simpleName)


            }



















        }




    }





    override fun onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }
}
