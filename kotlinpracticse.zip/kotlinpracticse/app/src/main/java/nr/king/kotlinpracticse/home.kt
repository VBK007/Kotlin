package nr.king.kotlinpracticse

import android.Manifest.permission
import android.os.Bundle
import android.widget.GridView
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.karan.churi.PermissionManager.PermissionManager
import nr.king.kotlinpracticse.Adapter.mainadapter
import nr.king.kotlinpracticse.Model.Myfav


class home : AppCompatActivity() {
    private var imageView:ImageView?=null
    private var txtdesc:TextView?=null
    var myhomeitems=ArrayList<Myfav>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

//         permission= object : PermissionManager() {}
//        permission.checkAndRequestPermissions(this)

        val permissionManager=object : PermissionManager() {

        }
        permissionManager.checkAndRequestPermissions(this)



        var gridView:GridView=findViewById(R.id.grid)
        var homeadapter:mainadapter?=null
        myhomeitems.add(Myfav("Gallery",R.drawable.gal))
        myhomeitems.add(Myfav("Calculator",R.drawable.cal))

        myhomeitems.add(Myfav("MultipleActivity",R.drawable.menu))

        myhomeitems.add(Myfav("WebView",R.drawable.browser))

        myhomeitems.add(Myfav("Drawing",R.drawable.draw))

        myhomeitems.add(Myfav("Notification",R.drawable.notifi))

        myhomeitems.add(Myfav("Table",R.drawable.table))

homeadapter=mainadapter(applicationContext,myhomeitems)

gridView.adapter=homeadapter













    }
}