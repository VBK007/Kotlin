package nr.king.kotlinpracticse

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class table : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_table)
    }
}