package nr.king.kotlinpracticse.Adapter

import android.animation.Animator
import android.content.Context
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import com.squareup.picasso.Picasso
import nr.king.kotlinpracticse.Model.Myfav
import nr.king.kotlinpracticse.R


class MyfavAdapter(private var context: Context?=null, private var myfavLists:ArrayList<Myfav>):BaseAdapter() {
    var myfavview: View = View.inflate(context, R.layout.cardimage, null)
    private var mScaleGestureDetector: ScaleGestureDetector? = null
    private var mScaleFactor = 1.0f
 private var ZoomControler:Int=20
    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
        var currentAnimation: Animator? = null
        var shortAnimationDuration: Int = 0

        var Myfavitem = myfavLists[p0]
        var myfavview: View = View.inflate(context, R.layout.cardimage, null)
        var imageView: ImageView = myfavview.findViewById(R.id.image)
        var txtdesc: TextView = myfavview.findViewById(R.id.txtdesc)

       Picasso.get()
           .load(Myfavitem.image!!)
           .into(imageView)
        txtdesc.setText(Myfavitem.name)






        imageView.setOnClickListener {

        


        }



        return myfavview
    }




//    private fun zoomImagefromthumb(imageView: ImageView, image: Int) {
//        var currentAnimation:Animator?=null
//        var shortAnimationDuration: Int = 0
//        currentAnimation?.cancel()
//
//        val expandimage: ImageView=myfavview.findViewById(R.id.image)
//        expandimage.setImageResource()
//
//
//
//    }


    override fun getItem(p0: Int): Any {
        return myfavLists[p0]
    }

    override fun getItemId(p0: Int): Long {
        return p0.toLong()
    }

    override fun getCount(): Int {
        return myfavLists.size
    }


    private inner class ScaleListener : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(scaleGestureDetector: ScaleGestureDetector): Boolean {
            mScaleFactor *= scaleGestureDetector.scaleFactor
            mScaleFactor = Math.max(0.1f, Math.min(mScaleFactor, 10.0f))
            var imageView: ImageView = myfavview.findViewById(R.id.image)
            imageView?.setScaleX(mScaleFactor)
            imageView?.setScaleY(mScaleFactor)
            return true
        }


    }


    fun onTouchEvent(
        motionEvent: MotionEvent,
        param: Any,
        function: () -> Unit
    ): Boolean {
        mScaleGestureDetector?.onTouchEvent(motionEvent)
        return true
    }

}
