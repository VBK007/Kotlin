package nr.king.kotlinpracticse

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_calculator.*
import net.objecthunter.exp4j.ExpressionBuilder
import kotlin.math.min

class calculator : AppCompatActivity() {
    private var answerpreview: TextView? = null
    private var one: FButton? = null
    private var two: FButton? = null
    private var three: FButton? = null
    private var four: FButton? = null
    private var five: FButton? = null
    private var six: FButton? = null
    private var seven: FButton? = null
    private var eight: FButton? = null
    private var nine: FButton? = null
    private var zero: FButton? = null
    private var doublezero: FButton? = null
    private var dot: FButton? = null

    private var plus: FButton? = null
    private var minus: FButton? = null
    private var mul: FButton? = null
    private var divide: FButton? = null
    private var equal: FButton? = null
    private var result: TextView? = null
    private var del: FButton? = null
    override fun onCreate(savedInstanceState: Bundle?) {


        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calculator)

        del = findViewById(R.id.del)
        one = findViewById(R.id.one)
        two = findViewById(R.id.two)
        three = findViewById(R.id.three)
        four = findViewById(R.id.four)
        five = findViewById(R.id.five)
        six = findViewById(R.id.six)
        seven = findViewById(R.id.seven)
        eight = findViewById(R.id.eigth)
        nine = findViewById(R.id.nine)
        zero = findViewById(R.id.zero)
        doublezero = findViewById(R.id.doublezero)
        answerpreview = findViewById(R.id.tvExpression)
        result = findViewById(R.id.tvResult)
        dot=findViewById(R.id.dot)

        plus=findViewById(R.id.add)
        minus=findViewById(R.id.sub)
        mul=findViewById(R.id.mul)
        divide=findViewById(R.id.divide)
equal=findViewById(R.id.equal)
        one?.setOnClickListener {
            appendOnExpresstion("1", true)


        }

        two?.setOnClickListener {
            appendOnExpresstion("2", true)


        }
        three?.setOnClickListener {
            appendOnExpresstion("3", true)


        }

        four?.setOnClickListener {
            appendOnExpresstion("4", true)


        }
        five?.setOnClickListener {
            appendOnExpresstion("5", true)


        }
        six?.setOnClickListener {
            appendOnExpresstion("6", true)


        }
        seven?.setOnClickListener {
            appendOnExpresstion("7", true)


        }
        eight?.setOnClickListener {
            appendOnExpresstion("8", true)


        }
        nine?.setOnClickListener {
            appendOnExpresstion("9", true)


        }
        zero?.setOnClickListener {
            appendOnExpresstion("0", true)


        }
        doublezero?.setOnClickListener {
            appendOnExpresstion("00", true)


        }
        dot?.setOnClickListener {
            appendOnExpresstion(".", true)


        }
        equal?.setOnClickListener {
            val expression = ExpressionBuilder( answerpreview?.text.toString()).build()

            val result = expression.evaluate()
            var longResult = result.toLong()
            if (result == longResult.toDouble()) {
                tvResult.text = longResult.toString()

                



            } else {

                tvResult.text = result.toString()
            }


        }

        del?.setOnClickListener {
            val string = answerpreview?.text.toString()
            if (string.isNotEmpty()) {
                answerpreview?.text = string.substring(0, string.length - 1)

            }

            tvResult.text = ""
        }







        plus?.setOnClickListener {
            appendOnExpresstion("+", true)


        }


        minus?.setOnClickListener {
            appendOnExpresstion("-", true)


        }

        mul?.setOnClickListener {
            appendOnExpresstion("*", true)


        }


        divide?.setOnClickListener {
            appendOnExpresstion("/", true)


        }


        clear.setOnClickListener {
            answerpreview?.text = ""
            tvResult?.text = ""

        }


    }

    private fun appendOnExpresstion(string: String, boolean: Boolean) {
        if(tvResult.text.isNotEmpty()){
            tvExpression.text = ""
        }

        if (boolean) {
            tvResult.text = ""
            tvExpression.append(string)
        } else {
            tvExpression.append(tvResult.text)
            tvExpression.append(string)
            tvResult.text = ""
        }

    }

}
