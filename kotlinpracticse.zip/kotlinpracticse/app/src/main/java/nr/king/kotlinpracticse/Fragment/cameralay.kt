package nr.king.kotlinpracticse.Fragment

import android.app.Activity
import android.app.Activity.RESULT_OK
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import kotlinx.android.synthetic.main.camerala.*
import nr.king.kotlinpracticse.R
import java.io.File

class cameralay:Fragment() {
    private  val IMAGE_CAPTURE=42;
    private val VIDEO_CAPTURE=202;
    lateinit var currentPhotopath:String
private lateinit var photofile:File

    private  val FILE_NAME="photo.jpg"
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View?=inflater.inflate(R.layout.camerala,container,false)


    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        imageview.visibility=View.GONE
        videoview.visibility=View.GONE




        cappic.setOnClickListener {
            uploadImage()



        }


        capvid.setOnClickListener {
            uploadvideo()
        }



    }

    private fun uploadvideo() {


        Intent(MediaStore.ACTION_VIDEO_CAPTURE).also { takeVideoIntent ->
            takeVideoIntent.resolveActivity(requireContext().packageManager)?.also {
                startActivityForResult(takeVideoIntent, VIDEO_CAPTURE)
            }
        }


    }












    private fun uploadImage() {
        Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
            photofile=getPhotoFile(FILE_NAME)

           val fileProvider= FileProvider.getUriForFile(requireContext(),"nr.king.kotlinpracticse.fileprovider",photofile)

           takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT,fileProvider)
            takePictureIntent.resolveActivity(requireContext().packageManager)?.also {


                startActivityForResult(takePictureIntent, IMAGE_CAPTURE)
            }
        }






    }

    private fun getPhotoFile(fileName: String): File {
      val storageDirectory=  activity?.getExternalFilesDir(Environment.DIRECTORY_PICTURES)



return File.createTempFile(fileName,".jpg",storageDirectory)
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {

        if (requestCode == IMAGE_CAPTURE && resultCode == RESULT_OK) {

            val imageBitmap = BitmapFactory.decodeFile(photofile.absolutePath)

            imageview.visibility=View.VISIBLE
videoview.visibility=View.GONE
            imageview.setImageBitmap(imageBitmap)
        }

      else  if (requestCode == VIDEO_CAPTURE && resultCode == RESULT_OK) {
            val videoUri=data?.data
            imageview.visibility=View.GONE
            videoview.visibility=View.VISIBLE
            videoview.setVideoURI(videoUri)
        }






    }








}