package nr.king.kotlinpracticse.Adapter

import android.animation.Animator
import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import nr.king.kotlinpracticse.*
import nr.king.kotlinpracticse.Model.Myfav

class mainadapter(private var context: Context?=null,private  val myhomeitem:ArrayList<Myfav>):BaseAdapter(){

    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
        var currentAnimator: Animator? = null
        var myhomitem=myhomeitem[p0]
        var myhome:View=View.inflate(context,R.layout.cardimage,null)
        var imageView:ImageView=myhome.findViewById(R.id.image)
        var txtdec:TextView=myhome.findViewById(R.id.txtdesc)
        imageView.setImageResource(myhomitem.image!!)
        txtdec.setText(myhomitem.name)

        imageView.setOnClickListener {

//           var progressDialog=ProgressDialog(context)
//            progressDialog.setMessage("Please wait loading" + myhomitem.name)
//            progressDialog.show()

            if (p0==0){
                val intent = Intent(context, MainActivity::class.java)
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
Toast.makeText(context,"You Enter into " +myhomitem.name,Toast.LENGTH_SHORT).show()
                context!!.startActivity(intent)


            }
            if (p0==1){
                val intent = Intent(context, calculator::class.java)
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                Toast.makeText(context,"You Enter into " +myhomitem.name,Toast.LENGTH_SHORT).show()
                context!!.startActivity(intent)


            }



            if (p0==2){
                val intent = Intent(context, menuHome::class.java)
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                Toast.makeText(context,"You Enter into " +myhomitem.name,Toast.LENGTH_SHORT).show()
                context!!.startActivity(intent)


            }
            if (p0==3){
                val intent = Intent(context, webview::class.java)
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                Toast.makeText(context,"You Enter into " +myhomitem.name,Toast.LENGTH_SHORT).show()
                context!!.startActivity(intent)


            }
            if (p0==4){
                val intent = Intent(context, draw::class.java)
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                Toast.makeText(context,"You Enter into " +myhomitem.name,Toast.LENGTH_SHORT).show()
                context!!.startActivity(intent)


            }
            if (p0==5){
                val intent = Intent(context, notify::class.java)
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                Toast.makeText(context,"You Enter into " +myhomitem.name,Toast.LENGTH_SHORT).show()
                context!!.startActivity(intent)


            }
            if (p0==6){
                val intent = Intent(context, calculator::class.java)
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                Toast.makeText(context,"You Enter into " +myhomitem.name,Toast.LENGTH_SHORT).show()
                context!!.startActivity(intent)


            }


            if (p0==7){
                val intent = Intent(context, table::class.java)
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                Toast.makeText(context,"You Enter into " +myhomitem.name,Toast.LENGTH_SHORT).show()
                context!!.startActivity(intent)


            }


        }



        return myhome

    }



    override fun getItem(p0: Int): Any {

        return myhomeitem[p0]

    }

    override fun getItemId(p0: Int): Long {
return p0.toLong()
    }

    override fun getCount(): Int {
        return myhomeitem.size

    }

}