package nr.king.kotlinpracticse

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*
import nr.king.kotlinpracticse.Adapter.MyfavAdapter
import nr.king.kotlinpracticse.Model.Myfav

class MainActivity : AppCompatActivity() {

    var myfavlist=ArrayList<Myfav>()

    var adapter:MyfavAdapter?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        myfavlist.add(Myfav("Myfav",R.drawable.g))
        myfavlist.add(Myfav("Myfav",R.drawable.grub))
        myfavlist.add(Myfav("Myfav",R.drawable.main))
        myfavlist.add(Myfav("Myfav",R.drawable.man))
        myfavlist.add(Myfav("Myfav",R.drawable.mm))
        myfavlist.add(Myfav("Myfav",R.drawable.home))
adapter=MyfavAdapter(applicationContext,myfavlist)

grid.adapter=adapter












    }


}