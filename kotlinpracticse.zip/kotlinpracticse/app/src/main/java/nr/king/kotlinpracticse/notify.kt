package nr.king.kotlinpracticse

import android.app.NotificationManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.rengwuxian.materialedittext.MaterialEditText
import kotlinx.android.synthetic.main.activity_notify.*

class notify : AppCompatActivity() {
    private var editTilr:MaterialEditText?=null
    private var edtbody:MaterialEditText?=null
    private val channelId="nr.king.kotlinpracticse"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notify)

edtbody=findViewById(R.id.body)
        editTilr=findViewById(R.id.title)

        sendhead.setOnClickListener {
            headNotification()


        }


        sendAlert.setOnClickListener {

            alertNotifi()
        }




    }

    private fun alertNotifi() {




    }

    private fun headNotification() {


        var builder = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(editTilr.toString())
            .setContentText(edtbody.toString())
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)






    }
}